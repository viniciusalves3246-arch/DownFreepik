# =========================================
# DOWNFREEPIK PRO (VERSÃO CORRIGIDA)
# Mantém 100% da lógica original + melhorias
# =========================================

import os
import io
import time
import threading
import requests
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image

# Selenium
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# =========================
# CONFIG UI
# =========================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# =========================
# CORE (CORRIGIDO COM BASE NO CÓDIGO QUE FUNCIONAVA)
# =========================
def extrair_imagem(url_pagina, formato, log):

    log("[BOOT] Iniciando navegador...")

    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--window-size=1920,1080")

    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)

    chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64)")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=chrome_options
    )

    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })

    try:
        log("[INFO] Abrindo página...")
        driver.get(url_pagina)

        wait = WebDriverWait(driver, 30)
        time.sleep(5)

        log("[INFO] Coletando imagens...")
        imagens = driver.find_elements(By.TAG_NAME, "img")
        log(f"[INFO] {len(imagens)} imagens encontradas")

        melhor_url = None
        melhor_size = 0

        # =========================
        # SRCSET (MESMO DO ORIGINAL)
        # =========================
        for img in imagens:
            try:
                srcset = img.get_attribute("srcset")

                if not srcset:
                    continue

                for item in srcset.split(","):
                    parts = item.strip().split(" ")

                    if len(parts) >= 2:
                        url = parts[0]
                        size = parts[1].replace("w", "")

                        try:
                            size = int(size)
                        except:
                            size = 0

                        if (
                            "img.freepik.com" in url and
                            "error" not in url and
                            size > melhor_size
                        ):
                            melhor_size = size
                            melhor_url = url

            except Exception as e:
                log(f"[WARN] srcset erro: {str(e)}")

        # =========================
        # FALLBACK (MESMO DO ORIGINAL)
        # =========================
        if not melhor_url:
            log("[WARN] srcset falhou, tentando src...")

            for img in imagens:
                src = img.get_attribute("src")

                if (
                    src and
                    "img.freepik.com" in src and
                    "error" not in src and
                    "profile" not in src
                ):
                    melhor_url = src
                    break

        if not melhor_url:
            raise Exception("Nenhuma imagem válida encontrada (bloqueio ou página incompleta)")

        melhor_url = melhor_url.split("?")[0]
        log(f"[OK] URL: {melhor_url}")

        # =========================
        # COOKIES + HEADERS
        # =========================
        cookies = {c['name']: c['value'] for c in driver.get_cookies()}

        headers = {
            "User-Agent": "Mozilla/5.0",
            "Referer": url_pagina
        }

        log("[DOWNLOAD] Baixando imagem...")
        res = requests.get(melhor_url, headers=headers, cookies=cookies, timeout=20)

        log(f"[HTTP] Status: {res.status_code}")

        if res.status_code != 200:
            raise Exception(f"HTTP {res.status_code}")

        if len(res.content) < 1000:
            raise Exception("Conteúdo inválido (bloqueado)")

        log(f"[OK] {len(res.content)} bytes recebidos")

        img = Image.open(io.BytesIO(res.content))
        return img

    finally:
        driver.quit()
        log("[CLOSE] Navegador fechado")


# =========================
# APP UI PROFISSIONAL
# =========================
class App(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("DownFreepik PRO")
        self.geometry("850x520")

        self.setup_ui()

    def setup_ui(self):

        self.grid_columnconfigure(1, weight=1)

        # LEFT PANEL
        frame = ctk.CTkFrame(self)
        frame.grid(row=0, column=0, padx=20, pady=20, sticky="ns")

        ctk.CTkLabel(
            frame,
            text="⚡ DownFreepik",
            font=ctk.CTkFont(size=24, weight="bold")
        ).pack(pady=20)

        self.url = ctk.CTkEntry(frame, width=300, placeholder_text="Cole a URL do Freepik...")
        self.url.pack(pady=10)

        self.format = ctk.CTkOptionMenu(
            frame,
            values=["PNG", "JPG", "WEBP", "BMP"]
        )
        self.format.set("PNG")
        self.format.pack(pady=10)

        self.progress = ctk.CTkProgressBar(frame, width=250)
        self.progress.pack(pady=15)

        self.status = ctk.CTkLabel(frame, text="Pronto", text_color="gray")
        self.status.pack()

        self.btn = ctk.CTkButton(
            frame,
            text="⬇ BAIXAR IMAGEM",
            command=self.start
        )
        self.btn.pack(pady=20)

        # LOG AREA
        self.logbox = ctk.CTkTextbox(self)
        self.logbox.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

    def log(self, msg):
        self.logbox.insert("end", msg + "\n")
        self.logbox.see("end")

    def start(self):

        url = self.url.get().strip()

        if not url:
            return messagebox.showwarning("Erro", "Cole a URL")

        path = filedialog.asksaveasfilename()

        if not path:
            return

        threading.Thread(
            target=self.process,
            args=(url, path),
            daemon=True
        ).start()

    def process(self, url, path):

        try:
            self.btn.configure(state="disabled")
            self.progress.start()
            self.status.configure(text="Processando...", text_color="blue")

            img = extrair_imagem(url, self.format.get(), self.log)

            formato = self.format.get().lower()

            if not path.endswith(f".{formato}"):
                path += f".{formato}"

            if formato == "jpg":
                img = img.convert("RGB")

            img.save(path, formato.upper())

            self.status.configure(text="Concluído", text_color="green")
            messagebox.showinfo("Sucesso", "Imagem salva com sucesso!")

        except Exception as e:
            self.log(f"[ERRO] {str(e)}")
            self.status.configure(text="Erro", text_color="red")

        finally:
            self.progress.stop()
            self.btn.configure(state="normal")


# =========================
# RUN
# =========================
if __name__ == "__main__":
    app = App()
    app.mainloop()