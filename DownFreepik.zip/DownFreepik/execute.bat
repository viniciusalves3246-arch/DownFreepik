@echo off
title DownFreepik PRO - Instalador Inteligente

echo =========================================
echo   Verificando dependencias...
echo =========================================
echo.

:: =========================
:: CHECK / INSTALL DEPENDENCIAS
:: =========================

echo [CHECK] requests
python -c "import requests" 2>nul || pip install requests

echo [CHECK] pillow (PIL)
python -c "import PIL" 2>nul || pip install pillow

echo [CHECK] customtkinter
python -c "import customtkinter" 2>nul || pip install customtkinter

echo [CHECK] selenium
python -c "import selenium" 2>nul || pip install selenium

echo [CHECK] webdriver-manager
python -c "import webdriver_manager" 2>nul || pip install webdriver-manager

echo [CHECK] certifi
python -c "import certifi" 2>nul || pip install certifi

echo [CHECK] urllib3
python -c "import urllib3" 2>nul || pip install urllib3

echo.
echo =========================================
echo   Todas dependencias OK
echo =========================================
echo.

:: =========================
:: VERIFICACAO FINAL
:: =========================
python -c "import requests, PIL, selenium, customtkinter; print('OK - Ambiente pronto!')"

echo.
echo =========================================
echo   CONFIGURANDO ESTRUTURA OCULTA...
echo =========================================
echo.

:: Criar pasta oculta
if not exist "core" (
    mkdir core
    echo [OK] Pasta core criada
)

:: Aplicar atributos ocultos
attrib +h +s +r "core"

:: Mover down.py se estiver fora
if exist "down.py" (
    move /Y down.py core\down.py >nul
    echo [OK] down.py movido para pasta oculta
)

echo.
echo =========================================
echo   INICIANDO DownFreepik...
echo =========================================
echo.

:: Executar script dentro da pasta oculta
py core\down.py

echo.
echo =========================================
echo   PROGRAMA ENCERRADO
echo =========================================
pause